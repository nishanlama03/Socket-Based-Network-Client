2. Code description

1. “Why This Works" explanation: 
